## 
## This demonstration shows the performance of RGeostats
## for performing categorical simulations within 
## the Truncated PluriGaussian Truncated Model
##
{
liste.initiale = ls()
on.exit(demo.clean(liste.initiale))
par(ask=FALSE)
projec.toggle(0,0)

# Build the output grid
nx <- 100
grid<-db.create(flag.grid=T,nx=c(nx,nx))
xvect = db.extract(grid,2) / nx

# Build a relevant color scale
palperso<-c("orange","blue","red")

# Load various data sets
data(Exdemo_simpgs.model)   	   # Cubic model
data(Exdemo_simpgs.neigh)   	   # Neighborhood(Unique)
data(Exdemo_simpgs_std.rule)       # Standard Rule (3 facies: S T F 2 F 3 F 1)
data(Exdemo_simpgs_shift.rule)     # Rule with shift
data(Exdemo_simpgs_shadow.rule)    # Rule with shadow

# Create non-stationary proportions
grid <- db.add(grid,p1=xvect)
grid <- db.add(grid,p3=(1-p1)/2)
grid <- db.add(grid,p2=(1-p1-p3))
grid <- db.locate(grid,seq(4,6),loctype="p")

# Close any previous screen #
split.screen(c(2,2),erase=TRUE)
screen(1)		
plot(grid,name.image="p1",zlim=c(0,1),reset=FALSE,title="Proportion Facies #1")
screen(2)		
plot(grid,name.image="p2",zlim=c(0,1),reset=FALSE,title="Proportion Facies #2")
screen(3)		
plot(grid,name.image="p3",zlim=c(0,1),reset=FALSE,title="Proportion Facies #3")
demo.pause("Proportions")
clean.window()

# Page with 4 different PGS realizations
split.screen(c(2,2),erase=TRUE)		

# Standard PGS with two underlying GRFs
screen(1)
plot(simpgs(dbout=grid,props=c(0.4,0.4,0.2),seed=12324,
	model1 = Exdemo_simpgs.model,
	model2 = Exdemo_simpgs.model,
	neigh  = Exdemo_simpgs.neigh,
	rule   = Exdemo_simpgs_std.rule),
	col    = palperso,reset=FALSE,
	title="PGS with 2 GRFs (Stat)")

screen(2)
plot(simpgs(dbout=grid,dbprop=grid,seed=12324,
	model1 = Exdemo_simpgs.model,
	model2 = Exdemo_simpgs.model,
	neigh  = Exdemo_simpgs.neigh,
	rule   = Exdemo_simpgs_std.rule),
	col    = palperso,reset=FALSE,
	title="PGS with 2 GRFs (Non Stat)")

# PGS with Shift
screen(3)
plot(simpgs(dbout=grid,props=c(.3,.3,.4),seed=123245,
	model1 = Exdemo_simpgs.model,
	neigh  = Exdemo_simpgs.neigh,
	rule   = Exdemo_simpgs_shift.rule),
	col    = palperso,reset=FALSE,
	title="PGS with Shift (Stat)")

screen(4)
plot(simpgs(dbout=grid,dbprop=grid,seed=12324,
	model1 = Exdemo_simpgs.model,
	neigh  = Exdemo_simpgs.neigh,
	rule   = Exdemo_simpgs_shift.rule),
	col    = palperso,reset=FALSE,
	title="PGS with Shift (Non Stat)")
demo.pause("PluriGaussians")
clean.window()

# Simulation followed by the threshold

split.screen(c(2,2),erase=TRUE)		
grid <- simtub(dbout=grid,model=Exdemo_simpgs.model,seed=12345,nbsimu=2)

screen(1)
plot(grid,reset=FALSE,title="Gaussian Simulation")

screen(2)
plot(db.rule(grid,
	rule  = Exdemo_simpgs_std.rule,
	model = Exdemo_simpgs.model,
	radix = "Simu.std"),
	col   = palperso,reset=FALSE,
	title="TGS (Standard)")

screen(3)
plot(db.rule(grid,
	rule  = Exdemo_simpgs_shift.rule,
	model = Exdemo_simpgs.model,
	radix = "Simu.shift"),
	col   = palperso,reset=FALSE,
	title="TGS (Shift)")

screen(4)
plot(db.rule(grid,
	rule  = Exdemo_simpgs_shadow.rule,
	model = Exdemo_simpgs.model,
	radix = "Simu.shadow"),
	col   = palperso,reset=FALSE,
	title="TGS (Shadow)")
demo.pause("Particular Thresholds")
}
