#######
# ICES CRR Handbook of geostatistics in R for fisheries and marine ecology
#
# R 3.1.2
# Rcpp 0.11.0
# RGeostats 11.0.2
# 
# This code implements different criteria to guide the choice of a
# kriging neighbourhood and performs kriging
# The criteria considered are:
#      The weight of the mean 
#      The decrease in kriging weights with distance to target
# Two neighborhoods are considered: 
#      A unique and a moving neighborhood 
# Two target points are considered: 
#      One is well informed by samples
#      One is not well informed
# Data are cross-validated with the neighborhood chosen (moving neighborhood)
# Mapping is performed using ordinary kriging in moving neighborhoood
# 
# The data correspond to a dredging survey of herring eggs on a spawning bed
# They were supplied by Marine Scotland Science at the Marine Laboratory,
# Aberdeen, UK 
#
# The data files are named demo.herreggs.scot and demo.herreggs.scot.poly
#
# Author: P.Petitgas, Ifremer 
#######

{
liste.initiale = ls()
on.exit(demo.clean(liste.initiale))
par(ask=FALSE)
  
######
### Data
######
                                        # limits of study area : limits of plots
x1lim<-25.9; x2lim<-26.5; y1lim<-17.0; y2lim<-17.58 
                                        # read data file and polygon
rg.load("Demo.herreggs.scot.db.data","db.data")
rg.load("Demo.herreggs.scot.poly.data","poly.data")
projec.toggle(0,verbose=FALSE)

                                        # select points inside polygon
db.data <- db.polygon(db.data,poly.data)
                                        # plot data and polygon
plot(db.data,name.prop="z1",xlab="",ylab="",
     xlim=c(x1lim,x2lim),ylim=c(y1lim,y2lim))
plot(poly.data,add=T,lty=1,density=0)
demo.pause("Display data")

                                        # mean, variance of data inside polygon
zm <- mean(db.data[,4][db.data[,5]]) 
zv <- var(db.data[,4][db.data[,5]])*(sum(db.data[,5])-1)/sum(db.data[,5])
cat("Mean: ",zm,"    var: ",zv,"   cv: ",sqrt(zv)/zm,"\n")

######
### Variogram
######
## No projection of coordinates: They are expressed in km from a reference point

                                        # Experimental variogram 
Lag <- 0.05; Nlag <- 9  
vg <- vario.calc(db.data, dirvect=0,lag=Lag, toldis=0.5, nlag=Nlag, 
                 calcul="vg", by.sample=FALSE, opt.code=0, tolcode=0, means=NA)
vario.plot(vg,npairdw=F,xlab="Distance (km)",ylab="Variogram",
           title="Experimental Variogram")
demo.pause("Experimental Variogram")

                                        # Fit a variogram model 
vg.init <- model.create("Nugget Effect",sill=50000,ndim=2)
vg.init <- model.create("Exponential",range=0.15,sill=370000,model=vg.init)
vg.fit  <- model.fit(vg, vg.init, niter=100, wmode=3, draw=F, flag.ask=F,
                     flag.fit=T)

                                        # overlay model and exp. variogram
plot(vg,npairdw=F,xlab="Distance (km)",ylab="Variogram",
     title="Variogram Model")
plot(vg.fit,vario=vg,lwd=3,add=T)
demo.pause("Model and Variogram")

#######
## Process mean
#######
cat("Estimating the Theoretical Mean...\n")
global.mt <- global(dbin=db.data, model=vg.fit, uc=c("1"), polygon=poly.data,
                    ndisc=100, calcul="mean", flag.polin=T, flag.wgt=T,
                    ivar=1, verbose=0)
mt <- global.mt$zest

######
### Estimation grid and selection of grid points for performing tests
######
                                        # Estimation grid wihtin polygon
x0 <- 25.9; y0 <- 17.0 ; dx <- 0.05; dy <- 0.05; nx <- 13;   ny <- 13
db.grid=db.create(flag.grid=T,x0=c(x0,y0),dx=c(dx,dy),nx=c(nx,ny))  
db.grid <- db.polygon(db.grid,poly.data)

                                        # View grid points, polygon and data
plot(db.grid, xlim=c(x1lim,x2lim),ylim=c(y1lim,y2lim),pch=3,
     title="Data & Grid")
plot(poly.data,add=T,lty=1,density=0)
plot(db.data,pch=18,add=T,col="black",inches=1.5)
demo.pause("Data & Grid")

                                # View index of grid points, polygon and data 
plot(db.grid, name.literal=1, title="Index of Grid Points",
     xlim=c(x1lim,x2lim),ylim=c(y1lim,y2lim),pch=3)
plot(poly.data,add=T,lty=1,density=0)
plot(db.data,pch=18,add=T,col="black",inches=1.5)
demo.pause("Index of grid points")

                                        # index of grid cells inside polygon 
igd <- (1:db.grid$nech)[db.grid[,4]] 
                                        # selection of grid points 
igdsel <- c(30,87)           

#######
## Neighbourhoods
## Evaluate performance of neighbourhoods at selected grid points
##  kriging weights should decrease with distance
##  weight of the process mean should be small
##  nb of samples not too low
## Choice: neighbourhood nei2 retained
#######

                                        # define neighbourhoods
nei1 <- neigh.create(ndim=2,type=0)                
nei2 <- neigh.create(ndim=2,type=2,nmini=2,nmaxi=8,radius=0.5)
jnei <- 2

                                        # computations for selected grid points
for (k in 1:jnei) {  
  neik <- get(paste("nei",k,sep=""))
  for (i in 1:length(igdsel)) {  

                                        # simple kriging
    kts <- krigtest(dbin=db.data, dbout=db.grid, model=vg.fit, neigh=neik,
                    uc = NA, mean = mt, calcul = "point", iech0=igdsel[i],
                    target=NA)

                                        # ordinary kriging
    kto <- krigtest(dbin=db.data, dbout=db.grid, model=vg.fit, neigh=neik,
                    uc = c("1"), calcul = "point", iech0=igdsel[i], target=NA)

                                # weight of process mean in neighbourhood
    lm <- 1-sum(kts$wgt) 
                                # nb samples in neighbourhood
    ns <- length(kts$wgt) 
                                # visualization of results
    plot(kto$xyz[,1:2],type="n",xlab="",ylab="",
         xlim=c(x1lim,x2lim),ylim=c(y1lim,y2lim),
         main=paste("Point",igdsel[i]," - neigh",k))
    text(x=26.4,y=17.50,paste("Wgt.mean:",round(lm,3)),cex=0.75)
    text(x=26.4,y=17.45,paste("Nb.obs :",ns),cex=0.75)
    plot(poly.data,add=T,lty=1,density=0)
    points(db.grid[igdsel[i],2:3],pch=3,col="blue")
    text(kto$xyz[,1:2],paste(round(kto$wgt[-length(kto$wgt)],2)),cex=0.8)
    demo.pause("Kriging test")
  }
}

######
### Cross-validation
######
db.data.xv <- xvalid(db=db.data, model=vg.fit, neigh=nei2, uc=c("1"), mean=NA)
                                        # Mean error (should be close to 0)
                                        # in percent of zone mean
mean(db.extract(db.data.xv, "Xvalid.eggs.esterr")) / zm
                                        # Mean standardized squared error
                                        # (should be close to 1) 
mean(db.extract(db.data.xv, "Xvalid.eggs.stderr")^2) 

######
### Mapping by ordinary kriging in moving neighborhood
######
                                        # Ordinary kriging in moving neigh.
kres <- kriging(dbin=db.data, dbout=db.grid, model=vg.fit, neigh=nei2, 
                uc=c("1"), mean=NA, calcul="point") 

                                        # Plot kriged estimates: K.estim
plot(kres,name.image=5,col=topo.colors(20),xlab="",
     ylab="",xlim=c(x1lim,x2lim),ylim=c(y1lim,y2lim),pos.legend=5,
     title="Kriged Estimate")
plot(db.data,pch=18,add=T,col="black",inches=1.5)
plot(poly.data,add=T)
demo.pause("Kriged Estimate")

                                        # Plot kriging errors : K.std
plot(kres,name.image=6,col=rev(gray((0:100)/100)),
     xlab="",ylab="", xlim=c(x1lim,x2lim), ylim=c(y1lim,y2lim), pos.legend=5,
     title="Kriged Standard Deviation")
plot(db.data,pch=18,add=T,col="black",inches=1.5)
plot(poly.data,add=T)
demo.pause("Kriged Standard Deviation")
}





